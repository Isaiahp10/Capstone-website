const basedPath = "../../images/demo/backgrounds"
const background = document.getElementById("bgnd");
const maxIndex = 2;
let slideshow = ["bambooForest.jpg","package.jpg","plastic.jpg"]
let currentIndex = 0;
var currentVariable = document.getElementById("nextbtn");
currentVariable.addEventListener("click",(e)=>{
    
    currentIndex ++;
    if (currentIndex  > maxIndex){

        currentIndex = 0;
    };


    background.style.backgroundImage = `url(${basedPath}/${slideshow[currentIndex]})`;

    console.log("Hi");
});

